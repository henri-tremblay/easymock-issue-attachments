package x;

public class B extends A {

}
