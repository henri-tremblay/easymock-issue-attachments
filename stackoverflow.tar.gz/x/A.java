package x;

abstract class A {
    
    @Override
    public String toString() {
        return this.getClass().getSimpleName();
    }

}
