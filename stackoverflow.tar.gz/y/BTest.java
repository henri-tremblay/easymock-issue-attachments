package y;

import org.junit.Test;
import static org.easymock.EasyMock.*;
import x.B;

public class BTest {

    @Test
    public void test() {
        
        B b = createMock(B.class);
        replay(b);
        
        System.out.println(b);
        
    }

}
