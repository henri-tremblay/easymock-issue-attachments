package com.baidu.pc.pager;


import java.util.List;
import java.util.Collections;

public class ServiceImpl implements IService{

	@SuppressWarnings("unchecked")
	public List<String> query(String key, int... startAndPerPages) {
		return Collections.EMPTY_LIST;
	}

}
