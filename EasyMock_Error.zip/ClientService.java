package com.baidu.pc.pager;


import java.util.List;

public class ClientService {
	private IService depenService;
	
	public List<String> query(String key, int... startAndPerPages) {
		List<String> rets = depenService.query(key, startAndPerPages);
		rets.add("aaaa");
		return rets;
	}

	public void setDepenService(IService depenService) {
		this.depenService = depenService;
	}
}
