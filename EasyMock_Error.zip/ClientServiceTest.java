package com.baidu.pc.pager;


import java.util.ArrayList;
import java.util.List;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;

public class ClientServiceTest {
	@Test
	public void query_page_error(){
	    ClientService clientService = new ClientService();
		IService mockService = EasyMock.createMock(IService.class);
		EasyMock.expect(mockService.query(EasyMock.anyObject(String.class),
				EasyMock.anyObject(Integer.class),EasyMock.anyObject(Integer.class)));
		
		EasyMock.replay(mockService);
		clientService.setDepenService(mockService);
		
		String key = "test";
		int startPage = 1;
		int recordsPerPage = 10;
		
		clientService.query(key, startPage,recordsPerPage);
		
		EasyMock.verify(mockService);
	}
	
	@Test
	public void query_page_correct(){
		ClientService clientService = new ClientService();
		 
		List<String> rets = new ArrayList<String>();
		
		IService mockService = EasyMock.createMock(IService.class);
		EasyMock.expect(mockService.query(EasyMock.anyObject(String.class),
				EasyMock.anyInt(),EasyMock.anyInt()))
				.andReturn(rets);
		
		EasyMock.replay(mockService);
		clientService.setDepenService(mockService);
		
		String key = "test";
		int startPage = 1;
		int recordsPerPage = 10;
		
		clientService.query(key, startPage,recordsPerPage);
		
		EasyMock.verify(mockService);
	}
}
