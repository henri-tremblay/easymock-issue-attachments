package com.baidu.pc.pager;


import java.util.List;

public interface IService {
	List<String> query(String key, int... startAndPerPages);
}
