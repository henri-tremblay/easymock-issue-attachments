package com.ryaltech.easymock;

public interface Collaborator {
	void invoke();

}
