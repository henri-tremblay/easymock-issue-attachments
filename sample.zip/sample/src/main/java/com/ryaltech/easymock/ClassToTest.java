package com.ryaltech.easymock;

public class ClassToTest {
	private Collaborator collaborator;

	ClassToTest(Collaborator collaborator) {
		this.collaborator = collaborator;
	}

	public void execute() {
		try {
			collaborator.invoke();
		} catch (Throwable ex) {
			// complex error handling logic...
			// Example that I encountered is Spring scheduler that logs and suppresses Throwable(which is understandable in their case).

			ex.printStackTrace();


		}
	}
}
