package com.ryaltech.easymock;

import static org.easymock.EasyMock.createStrictControl;
import static org.easymock.EasyMock.*;

import org.easymock.IMocksControl;
import org.junit.Test;

public class IllustrativeTest {
	@Test
	public void testCallExtraMethods() {
		IMocksControl mockControl = createStrictControl();
		Collaborator mockCollaborator = mockControl
				.createMock(Collaborator.class);
		replay(mockCollaborator);
		new ClassToTest(mockCollaborator).execute();
		;
		// this passes
		// would be nice if there was verify mode that catches not only cases
		// when we did not meet expectations but also cases when we called extras
		// those extras typically cause exception in test execution and hence test failure
		// but not in cases when Throwable is caught
		verify(mockCollaborator);

	}

}
